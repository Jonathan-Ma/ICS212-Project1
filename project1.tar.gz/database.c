/*****************************************************************
//
//  NAME:        Jonathan Ma
//
//  HOMEWORK:    3
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 2, 2020
//
//  FILE:        database.c
//
//  DESCRIPTION:
//   Contains all the functions for the database.
//
****************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "record.h"
#include "database.h"
extern int debugMode;

/*****************************************************************
//
//  Function name: addRecord
//
//  DESCRIPTION:   This function gets the users
//                 name and account number
//                 
//
//  Parameters:    bar (int) : The account number
//                 bar (char[]): The users name
//                 bar (char[]); The users mailing address
//
//  Return values:  0 : The users name, account number, and mailing address are 
//                      registered successfully.
//                 
//                  1 : debug mode
//                 
****************************************************************/

int addRecord (struct record **start, int accountnum, char name[],char address[])
{
    struct record* node;
    struct record* prev;
    prev = *start;
    node = *start;

    if(debugMode == 1 )
    {
        printf("\nFunction addRecord called, paramters passed are account number, name, mailing address, and start.\n");
        return 1;
    }
    
 
    if (*start == NULL)
    {   
        struct record* nnode = (struct record*)malloc(sizeof(struct record));
        nnode->accountnum = accountnum;
        strcpy(nnode->name, name);
        strcpy(nnode->address, address);
        nnode->next = NULL;
        *start = nnode;
    }

    else if(*start != NULL)
    {
        struct record *temp = (struct record *)malloc(sizeof(struct record));
        temp->accountnum = accountnum;
        strcpy(temp->name, name);
        strcpy(temp->address, address);
       
        if(accountnum >= node->accountnum)
        {
            temp->next = *start;
            *start = temp;            
        }
        
        else
        {
            if(accountnum < node->accountnum && node->next != NULL)
            {
                node = node->next;
            }
            while(accountnum < node->accountnum && node->next != NULL)
            {   
                prev = prev->next;
                node = node->next;
            }
            if(accountnum >= node->accountnum)
            {
                temp->next = node;
                prev->next = temp;
            }
            else if(node->accountnum > accountnum && node->next == NULL)
            {                
                temp->next = NULL;
                node->next = temp;
            }
        }
    }
return 0;
}
/******************************************************************
//
//
//  Function name: printALLRecords
//
//  Description:   This function will print the records of all the 
//                 the clients information.
//
//  
//
//  Parameters:    bar (struct record): Contains the datatypes of 
//                                      name, accoount number, and 
//                                      mailing address.
//
//
//  
//  return values:   none
// 
//
//
//
*******************************************************************/
void printAllRecords(struct record *start)
{
   if(debugMode == 1)
    {
        printf("\nFunction printALLRecords called, start is passed.\n");
    }

    else if(start == NULL)
    {
        printf("\nNo accounts are present.\n");
    }

    else
    {
        while(start != NULL)
        {
            printf("\nAccount Number: %d\nName: %s\nAddress: \n%s\n", start->accountnum, start->name, start->address);
            start = start->next;
        }
    }

}
/*******************************************************************
//  Function name: findRecord
//
//  parameters:    bar (struct record): Contains the datatypes of 
//                                      client name, account number
//                                      and mailing address
//                 
//                 bar (int): The account number
//
//
//
//  return values:  0: The record of the account associated with the 
//                     account number is returned 
//                
//                  1: debug mode called;
//
*********************************************************************/
int findRecord(struct record *start, int accountnum)
{
    int counter = 0;
    if(debugMode == 1)
    {
        printf("\nFunction findRecord called, account number and start is passed.\n");
        return 1;
    }

    if(start == NULL)
    {
        printf("\nNo accounts in database to find.\n");
    }

    else if(start != NULL)
    {
        while(start != NULL)
        {
            if(accountnum == start->accountnum)
            {
                counter++;
                printf("\nFound Account: %d\nName: %s\nAddress: %s\n", start->accountnum, start->name, start->address);
            }
            if(counter == 0 && start->next == NULL)
            {
                printf("\nNo accounts found.\n");
                return 1;
            }
            else
            {
                start = start->next;

            }
         }
     }   

return 0;
}
/********************************************************************
//  Function name: deleteRecord
//
//  parameters:    bar (struct record): Contains the datatypes for 
//                                      client name, account, and account 
//                                      number
//                 bar (int): The account number
//
//  return values: 0: successful deletion of an account
//                 1: deletion was not successful or debug mode
********************************************************************/
int deleteRecord(struct record **start, int accountnum)
{
    int counter = 0;

    struct record* cur;
    struct record* prev;
    cur = *start;

    if(debugMode == 1) 
    {
        printf("\nFunction deleteRecord called, account number and start is passed.\n");
        return 1;
    }

    if(*start == NULL)
    {
        printf("\nNothing in data to delete.\n");
        return 1;
    }

    if(cur->next == NULL && cur == *start)
    {
        *start = NULL;
        printf("\nAccount number: %d\nName: %s\nAddress: %s\nDeleted.\n",cur->accountnum, cur->name, cur->address);
        free(cur);
        return 1;
    }

    while(cur != NULL)
    {
        if(accountnum == cur->accountnum && cur == *start)
        {
            prev = cur;
            cur = cur->next;
            printf("\nAccount number: %d\nName: %s\nAddress: %s\nDeleted.\n", prev->accountnum, prev->name, prev->address);
            free(prev);
            *start = cur;
            counter++;
        }
        else if(accountnum == cur->accountnum && cur->next != NULL)
        {
            prev->next = cur->next;
            printf("\nAccount number: %d\nName: %s\nAddress: %s\nDeleted.\n", cur->accountnum, cur->name, cur->address);
            free(cur);
            cur = prev->next;
            counter++;
        }

        else if(accountnum == cur->accountnum && cur->next == NULL)
        {
            prev->next = NULL;
            printf("\nAccount number: %d\nName: %s\nAddress: %s\nDeleted.\n", cur->accountnum, cur->name, cur->address);
            free(cur);
            counter++;
            return 0;
        }

        else if(counter == 0 && cur->next == NULL)
        {
            printf("\nAccount does not exist.\n");
            return 1;
        }

        else
        {
            prev = cur;
            cur = cur->next;
        }

    }
    

     
return 0;
}

/***************************************************************** 
// 
// Function name: readfile 
// 
// DESCRIPTION: 
// 
// 
// Parameters: bar (int) : contains the number of arguments 
// which will be processed 
// 
// Return values: 0 : successfully read the file and parsed everything 
// into the array 
// 
// -1 : file not found or other error opening file. 
//
****************************************************************/

int readfile(struct record ** start, char filename[ ])
{    
    FILE *fp = fopen(filename, "r");

    int accountno;
    char name[25];
    char address[80];
    char line[80];
    int i;
    if(debugMode == 1 )
    {
        printf("\nFunction readfile called, filename and start is passed .\n");
        return 1;
    }

    if(fp == NULL)
    {
        printf("\nCOULD NOT FIND FILE.");
        return -1;
    }

    while(!feof(fp))
    { 
        fgets(line, 80, fp);
        accountno = atoi(line);
        
        if(feof(fp))
        {
        break;
        } 

        fgets(line, 80, fp);
        strcpy(name, line);
        name[strlen(line) - 1] = '\0';
        
        i = 0;        
        for(; i < 80; i++)
        {
            address[i] = fgetc(fp);
            if( address[i] == '\n' && address[i - 1] == '\n')
            {
                address[i - 1] = '\0';
                address[i] = '\0';                                
                break;

            }
        }

        addRecord(start, accountno, name, address);             

    }
    fclose(fp);
    return 0; 
}

/*****************************************************************
//
// Function name: write
//
// DESCRIPTION: This function writes all the records
//              in the database to file at the end of the program.
//
// Parameters: start (struct record *) : pointer to the start of the record
//             filename (char[]): an array of char containing the file name
//
// Return values: 0: wrote to file 
//                1: in debug mode
******************************************************************/

int writefile(struct record * start, char filename[])
{
    struct record * temp;
    FILE *write = fopen(filename, "w");
    temp = start;

    if(debugMode == 1 )
    {
        printf("\nFunction writefile is called, filename and start is passed.\n");
        return 1;
    }
    
    while(temp != NULL)
    {
        fprintf(write, "%d\n%s\n%s\n\n", temp->accountnum, temp->name, temp->address);
        temp = temp->next;
    }
    fclose(write);
    return 0;
}

/*****************************************************************
//
// Function name: cleanup
//
// DESCRIPTION: This function releases all allocated space in heap
//              in the memory and assign NULL to start.
//
// Parameters: start (struct record *) : pointer to the start of the record
//             filename (char[]): an array of char containing the file name
//
// Return values: n/a (void)
//
******************************************************************/

void cleanup(struct record ** start)
{
    if(debugMode == 1 )
    {
        printf("\nFunction cleanup is called, start is passed.\n");
    }
    else
    {
        free(*start);
        *start = NULL;
    }
}
